from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    created_at: datetime
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: str | None = None

class DocumentResponse(BaseModel):
    id: int
    filename: str
    content_type: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True


class DocumentPageBase(BaseModel):
    page_number: int
    text_content: Optional[str] = None
    fallback_needed: bool
    parser_used: Optional[str] = None

class DocumentPageResponse(DocumentPageBase):
    id: int
    document_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class DocumentChunkBase(BaseModel):
    page_number: int
    chunk_index: int
    text: str
    start_offset: int
    end_offset: int

class DocumentChunkResponse(DocumentChunkBase):
    id: int
    document_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class DocumentSearchRequest(BaseModel):
    query: str
    top_k: int = 5
    document_ids: Optional[List[int]] = None

class DocumentSearchResult(BaseModel):
    chunk: DocumentChunkResponse
    similarity: float
    document_filename: str

class QueryRequest(BaseModel):
    query: str
    document_id: int
    top_k: int = 5
    mode: str = "audit" # "audit" (strict) or "summary" (conversational)

class Citation(BaseModel):
    page_number: int
    chunk_index: int
    text: str
    similarity: float

class QueryResponse(BaseModel):
    status: str  # "answered" | "refused"
    answer: Optional[str] = None
    confidence: float
    support_level: Optional[str] = None  # "supported" | "partially_supported" | "unsupported"
    answer_mode: Optional[str] = None    # "extractive" | "synthesis"
    citations: List[Citation] = []
    refusal_message: Optional[str] = None
    diagnostics: Optional[dict] = None
